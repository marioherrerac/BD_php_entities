<?php
    
    Route::get('/',function() { echo 'Hello, World!'; });
    
    Route::dispatch();
?>
